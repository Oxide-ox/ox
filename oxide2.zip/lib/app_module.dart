import 'package:modules/auth/module/auth_module.dart';
import 'package:modules/login/module/login_module.dart';
import 'package:flutter_modular/flutter_modular.dart';

import 'modules/module/home_module.dart';

class AppModule extends Module {
  @override
  final List<Bind> binds = [];

  @override
  final List<ModularRoute> routes = [
    ModuleRoute('/', module: AuthModule()),
    ModuleRoute('/login', module: LoginModule()),
    ModuleRoute('/home', module: HomeModule()),
  ];
}